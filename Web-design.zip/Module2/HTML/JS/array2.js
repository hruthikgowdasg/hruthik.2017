





//unshift
no.unshift(1)