var calculatorArea=function(width,height)
{
    return width*height;
};

var area=calculatorArea(5,3);
console.log(area);