console.log("HelloWorld");
console.log('Hello, World!');
