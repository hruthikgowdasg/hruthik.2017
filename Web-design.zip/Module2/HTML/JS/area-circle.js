function calculateArea(radius){
    return Math.Pi*Math.pow(radius,2);
}
var radius = 5;
var area=calculateArea(radius);
console.log("The area of the circle is:"+area);