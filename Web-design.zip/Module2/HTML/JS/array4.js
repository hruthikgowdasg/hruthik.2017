//map and filter in this
let nos = [4, 2, 13, 4, 25, 6, 17, 8];
nos.map(
    function (n) {
        if (n > 10) {
            console.log(n ** 2);

        }
    }
)
