{
    var a = 5;
    let b = 10;
}
console.log(a);
//console.log(b);