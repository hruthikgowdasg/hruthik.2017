function
addNumbers(a,b){
    return a+b;
}

var result=addNumbers(3,4);
console.log(result);
