let nos = [1, 2, 3, 4, 5, 6, 7, 8]
print the  array initially
console.log("The initial array is :", nos);
//print the length of the array
console.log("The length of the array is :", nos.length);
//print the first element
console.log("The 1st element of array is :", nos[0]);
//last element
consol.log("The last element of array is :", nos[nos.length - 1]);