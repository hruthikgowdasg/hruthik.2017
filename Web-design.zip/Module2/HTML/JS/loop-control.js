for(var i=1; i<=5; i++){
    if(i==4){
        break;
    }
    console.log(i);
}