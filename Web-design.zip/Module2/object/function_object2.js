function calculate(n)
{
    var vals ={};
    vals.db1 = n * 2;
    vals.tp1 = n * 3;
    return vals;
}
var v = calculate(5)
console.log(v);

