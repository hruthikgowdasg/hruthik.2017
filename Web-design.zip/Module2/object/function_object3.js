function wishme(student) {
    console.log("Welcome" + " " + student);
}
let m = wishme("Saba")
console.log(m);