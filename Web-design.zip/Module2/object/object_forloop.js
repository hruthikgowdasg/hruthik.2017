const person = {
    firstName: "John",
    lastName: "Doe",
    age: 30,
    occupation: "Engineer"
};
for (i in person) {
    console.log(person[i]);
}