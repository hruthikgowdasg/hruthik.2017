business={
    name: "Biztech",
        type: "Ecommerce",
            turnover: 200000,
}
let n = business.name;
let t = business.type;
let o = business.turnover;
console.log(n + " " + t + " "+0);