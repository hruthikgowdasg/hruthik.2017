//objects are defined as name:value key pairs
let student =
{
    sname: "Raj",
    age: 18,
    branch:"AI/ML"
}
//console.log(student["sname"]);
//
onsole.log(student.sname);
console.log(student.age);
console.log(student.branch);